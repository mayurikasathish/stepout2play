const prisma = require('../lib/prisma');

class SchedulerService {
  /**
   * Auto-schedule all matches for an event
   */
  async autoScheduleEvent(eventId, options = {}) {
    console.log('Starting auto-schedule for event:', eventId);

    // Get event with matches and tournament
    const event = await prisma.event.findUnique({
      where: { id: eventId },
      include: {
        matches: {
          orderBy: [
            { roundNumber: 'desc' }, // First round first (highest number)
            { matchNumber: 'asc' }
          ]
        },
        tournament: true
      }
    });

    if (!event) {
      const error = new Error('Event not found');
      error.statusCode = 404;
      throw error;
    }

    console.log('Event found:', event.name, 'Matches:', event.matches.length);

    // Get scheduling config (use options overrides or tournament defaults)
    const config = {
      dailyStartTime: options.dailyStartTime || event.tournament.dailyStartTime || '09:00',
      dailyEndTime: options.dailyEndTime || event.tournament.dailyEndTime || '18:00',
      courtsAvailable: options.courtsAvailable || event.tournament.courtsAvailable || 4,
      matchDuration: options.matchDuration || event.tournament.matchDuration || 45,
      breakDuration: options.breakDuration || event.tournament.breakDuration || 15,
      minRestTime: options.minRestTime || event.tournament.minRestTime || 30,
      firstMatchDate: options.firstMatchDate || event.tournament.firstMatchDate || event.tournament.startDate
    };

    // Validate config
    if (!config.firstMatchDate) {
      const error = new Error('First match date not set. Please configure tournament scheduling.');
      error.statusCode = 400;
      throw error;
    }

    // Filter out BYE matches
    const matchesToSchedule = event.matches.filter(m => m.status !== 'BYE');

    console.log('Scheduling event:', eventId);
    console.log('Matches to schedule:', matchesToSchedule.length);
    console.log('Config:', config);

    if (matchesToSchedule.length === 0) {
      return {
        success: true,
        message: 'No matches to schedule',
        summary: {
          totalMatches: 0,
          scheduledMatches: 0
        }
      };
    }

    // Find finals match (sacred - schedule last)
    const finalsMatch = matchesToSchedule.find(m => m.roundNumber === 1);

    // Generate time slots
    const slots = this.generateTimeSlots(config);
    console.log('Generated slots:', slots.length);

    // Track scheduled matches
    const schedule = [];
    const courtOccupancy = {}; // { courtNumber: [{ start, end }] }
    const playerLastMatch = {}; // { participantId: lastEndTime }

    // Schedule non-finals matches first
    const regularMatches = matchesToSchedule.filter(m => m.roundNumber !== 1);

    for (const match of regularMatches) {
      const slot = this.findAvailableSlot(
        match,
        slots,
        courtOccupancy,
        playerLastMatch,
        config
      );

      if (!slot) {
        // Cannot fit all matches
        console.log('Could not find slot for match:', match.id, 'after scheduling', schedule.length, 'matches');
        return {
          success: false,
          error: 'Cannot fit all matches in tournament duration',
          canFit: schedule.length,
          total: matchesToSchedule.length,
          suggestion: 'Add more courts, extend tournament dates, or reduce match duration'
        };
      }

      schedule.push({
        matchId: match.id,
        scheduledAt: slot.start,
        duration: config.matchDuration,
        courtNumber: slot.court
      });

      // Mark court as occupied
      if (!courtOccupancy[slot.court]) courtOccupancy[slot.court] = [];
      courtOccupancy[slot.court].push({
        start: slot.start,
        end: slot.end
      });

      // Update player last match times
      if (match.participant1Id) {
        playerLastMatch[match.participant1Id] = slot.end;
      }
      if (match.participant2Id) {
        playerLastMatch[match.participant2Id] = slot.end;
      }
    }

    // Schedule finals match LAST (sacred placement)
    if (finalsMatch) {
      // Find last slot in the tournament (or as specified)
      const finalsSlot = this.findFinalsSlot(
        finalsMatch,
        slots,
        courtOccupancy,
        playerLastMatch,
        config,
        schedule.length > 0 ? schedule[schedule.length - 1].scheduledAt : null
      );

      if (!finalsSlot) {
        return {
          success: false,
          error: 'Cannot schedule finals match',
          suggestion: 'Extend tournament end date'
        };
      }

      schedule.push({
        matchId: finalsMatch.id,
        scheduledAt: finalsSlot.start,
        duration: config.matchDuration,
        courtNumber: finalsSlot.court,
        isFinalsMatch: true
      });
    }

    // Save schedule to database
    await this.saveSchedule(schedule);

    // Calculate summary
    const scheduledDates = schedule.map(s => new Date(s.scheduledAt));
    const firstMatch = new Date(Math.min(...scheduledDates));
    const lastMatch = new Date(Math.max(...scheduledDates));
    const daysUsed = Math.ceil((lastMatch - firstMatch) / (1000 * 60 * 60 * 24)) + 1;

    return {
      success: true,
      message: 'All matches scheduled successfully',
      summary: {
        totalMatches: matchesToSchedule.length,
        scheduledMatches: schedule.length,
        firstMatchDate: firstMatch.toISOString(),
        lastMatchDate: lastMatch.toISOString(),
        daysUsed,
        courtsUsed: config.courtsAvailable
      }
    };
  }

  /**
   * Generate time slots based on tournament config
   */
  generateTimeSlots(config) {
    const slots = [];
    const startDate = new Date(config.firstMatchDate);
    const slotDuration = config.matchDuration + config.breakDuration;

    console.log('=== GENERATING TIME SLOTS ===');
    console.log('Start date:', startDate);
    console.log('Match duration:', config.matchDuration, 'min');
    console.log('Break duration:', config.breakDuration, 'min');
    console.log('Slot duration (match + break):', slotDuration, 'min');
    console.log('Daily hours:', config.dailyStartTime, '-', config.dailyEndTime);
    console.log('Courts available:', config.courtsAvailable);

    // Generate slots for multiple days (30 days max to prevent infinite loop)
    for (let day = 0; day < 30; day++) {
      const currentDate = new Date(startDate);
      currentDate.setDate(startDate.getDate() + day);

      // Parse daily start/end times
      const [startHour, startMin] = config.dailyStartTime.split(':').map(Number);
      const [endHour, endMin] = config.dailyEndTime.split(':').map(Number);

      const dayStart = new Date(currentDate);
      dayStart.setHours(startHour, startMin, 0, 0);

      const dayEnd = new Date(currentDate);
      dayEnd.setHours(endHour, endMin, 0, 0);

      let slotsThisDay = 0;

      // Generate slots for this day
      let slotStart = new Date(dayStart);
      while (slotStart < dayEnd) {
        const slotEnd = new Date(slotStart.getTime() + config.matchDuration * 60000);

        if (slotEnd <= dayEnd) {
          // Create slot for each court
          for (let court = 1; court <= config.courtsAvailable; court++) {
            slots.push({
              start: new Date(slotStart),
              end: new Date(slotEnd),
              court,
              day
            });
            slotsThisDay++;
          }
        }

        slotStart = new Date(slotStart.getTime() + slotDuration * 60000);
      }

      if (slotsThisDay > 0) {
        console.log(`Day ${day}: Generated ${slotsThisDay} slots (${slotsThisDay / config.courtsAvailable} time periods × ${config.courtsAvailable} courts)`);
      }
    }

    console.log('=== TOTAL SLOTS GENERATED:', slots.length, '===\n');
    return slots;
  }

  /**
   * Find available slot for a match
   */
  findAvailableSlot(match, slots, courtOccupancy, playerLastMatch, config) {
    console.log('Finding slot for match:', match.id, 'Participants:', match.participant1Id, match.participant2Id);
    console.log('Total slots available:', slots.length);
    console.log('Court occupancy:', Object.keys(courtOccupancy).length, 'courts occupied');

    for (let i = 0; i < slots.length; i++) {
      const slot = slots[i];

      // Check if court is available
      const courtBusy = courtOccupancy[slot.court]?.some(occupied => {
        return (slot.start >= occupied.start && slot.start < occupied.end) ||
               (slot.end > occupied.start && slot.end <= occupied.end);
      });

      if (courtBusy) {
        console.log(`Slot ${i} - Court ${slot.court} is busy`);
        continue;
      }

      // Check if participants are available
      if (match.participant1Id) {
        const p1LastMatch = playerLastMatch[match.participant1Id];
        if (p1LastMatch) {
          const restTime = (slot.start - p1LastMatch) / 60000; // minutes
          if (restTime < config.minRestTime) {
            console.log(`Slot ${i} - P1 needs rest (${restTime.toFixed(0)} min < ${config.minRestTime} min)`);
            continue;
          }
        }
      }

      if (match.participant2Id) {
        const p2LastMatch = playerLastMatch[match.participant2Id];
        if (p2LastMatch) {
          const restTime = (slot.start - p2LastMatch) / 60000; // minutes
          if (restTime < config.minRestTime) {
            console.log(`Slot ${i} - P2 needs rest (${restTime.toFixed(0)} min < ${config.minRestTime} min)`);
            continue;
          }
        }
      }

      // Slot is available
      console.log(`Found available slot ${i}: Court ${slot.court}, Time: ${slot.start}`);
      return slot;
    }

    console.log('NO AVAILABLE SLOT FOUND for match', match.id);
    return null;
  }

  /**
   * Find slot for finals match (schedule at end, or postpone if needed)
   */
  findFinalsSlot(match, slots, courtOccupancy, playerLastMatch, config, lastScheduledMatchTime) {
    // Try to find slot AFTER all other matches
    let startSearchFrom = lastScheduledMatchTime
      ? new Date(lastScheduledMatchTime.getTime() + config.minRestTime * 60000)
      : new Date(config.firstMatchDate);

    // Find available slots after the start time
    const availableSlots = slots.filter(slot => slot.start >= startSearchFrom);

    for (const slot of availableSlots) {
      // Check if court is available
      const courtBusy = courtOccupancy[slot.court]?.some(occupied => {
        return (slot.start >= occupied.start && slot.start < occupied.end) ||
               (slot.end > occupied.start && slot.end <= occupied.end);
      });

      if (courtBusy) continue;

      // Check if participants are available (if they exist)
      if (match.participant1Id) {
        const p1LastMatch = playerLastMatch[match.participant1Id];
        if (p1LastMatch) {
          const restTime = (slot.start - p1LastMatch) / 60000;
          if (restTime < config.minRestTime) continue;
        }
      }

      if (match.participant2Id) {
        const p2LastMatch = playerLastMatch[match.participant2Id];
        if (p2LastMatch) {
          const restTime = (slot.start - p2LastMatch) / 60000;
          if (restTime < config.minRestTime) continue;
        }
      }

      // Found suitable finals slot
      return slot;
    }

    return null;
  }

  /**
   * Save schedule to database
   */
  async saveSchedule(schedule) {
    const updates = schedule.map(item => {
      return prisma.match.update({
        where: { id: item.matchId },
        data: {
          scheduledAt: item.scheduledAt,
          duration: item.duration,
          courtNumber: item.courtNumber,
          isFinalsMatch: item.isFinalsMatch || false,
          status: 'SCHEDULED'
        }
      });
    });

    await prisma.$transaction(updates);
  }

  /**
   * Get schedule for an event
   */
  async getEventSchedule(eventId) {
    const event = await prisma.event.findUnique({
      where: { id: eventId },
      include: {
        tournament: true,
        matches: {
          where: {
            scheduledAt: { not: null }
          },
          include: {
            participant1: {
              include: {
                user: { select: { id: true, firstName: true, lastName: true, email: true } },
                partner: { select: { id: true, firstName: true, lastName: true } }
              }
            },
            participant2: {
              include: {
                user: { select: { id: true, firstName: true, lastName: true, email: true } },
                partner: { select: { id: true, firstName: true, lastName: true } }
              }
            }
          },
          orderBy: { scheduledAt: 'asc' }
        }
      }
    });

    if (!event) {
      const error = new Error('Event not found');
      error.statusCode = 404;
      throw error;
    }

    // Group by day and court
    const schedule = this.groupScheduleByDay(event.matches);

    return {
      event: {
        id: event.id,
        name: event.name,
        format: event.format
      },
      tournament: {
        id: event.tournament.id,
        name: event.tournament.name,
        venueName: event.tournament.venueName
      },
      schedule
    };
  }

  /**
   * Group matches by day and court
   */
  groupScheduleByDay(matches) {
    const days = {};

    matches.forEach(match => {
      if (!match.scheduledAt) return;

      const date = new Date(match.scheduledAt).toISOString().split('T')[0];

      if (!days[date]) {
        days[date] = {
          date,
          courts: {}
        };
      }

      const court = match.courtNumber || 1;
      if (!days[date].courts[court]) {
        days[date].courts[court] = [];
      }

      days[date].courts[court].push(match);
    });

    // Convert to array format
    return Object.values(days).map(day => ({
      date: day.date,
      courts: Object.entries(day.courts).map(([courtNum, matches]) => ({
        courtNumber: parseInt(courtNum),
        matches
      }))
    }));
  }

  /**
   * Clear schedule for an event
   */
  async clearSchedule(eventId) {
    await prisma.match.updateMany({
      where: { eventId },
      data: {
        scheduledAt: null,
        duration: null,
        courtNumber: null,
        courtName: null,
        status: 'PENDING'
      }
    });

    return { message: 'Schedule cleared successfully' };
  }
}

module.exports = new SchedulerService();
