SELECT migration_name FROM _prisma_migrations ORDER BY finished_at DESC LIMIT 5;
