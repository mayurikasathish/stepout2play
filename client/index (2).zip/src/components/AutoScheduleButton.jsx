import { useState } from 'react'
import api from '../services/api'

const CalendarIcon = (props) => (
  <svg {...props} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
  </svg>
)

const ClockIcon = (props) => (
  <svg {...props} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
)

const AlertIcon = (props) => (
  <svg {...props} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
  </svg>
)

const CheckIcon = (props) => (
  <svg {...props} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
  </svg>
)

const AutoScheduleButton = ({ eventId, eventName, onScheduled }) => {
  const [scheduling, setScheduling] = useState(false)
  const [showError, setShowError] = useState(false)
  const [errorDetails, setErrorDetails] = useState(null)
  const [showSuccess, setShowSuccess] = useState(false)
  const [successDetails, setSuccessDetails] = useState(null)

  const handleAutoSchedule = async () => {
    setScheduling(true)
    setShowError(false)
    setShowSuccess(false)

    try {
      const response = await api.post(`/events/${eventId}/auto-schedule`, {})

      if (response.data.success) {
        setSuccessDetails(response.data.summary)
        setShowSuccess(true)
        onScheduled && onScheduled(response.data)
      }
    } catch (err) {
      console.error('Auto-schedule error:', err)
      const errorData = err.response?.data
      if (errorData && !errorData.success) {
        setErrorDetails(errorData)
        setShowError(true)
      }
    } finally {
      setScheduling(false)
    }
  }

  return (
    <>
      <button
        onClick={handleAutoSchedule}
        disabled={scheduling}
        className="group relative px-8 py-4 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-3"
      >
        <div className="absolute inset-0 bg-white/20 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
        <CalendarIcon className="w-6 h-6 relative z-10" />
        <span className="relative z-10">
          {scheduling ? 'Scheduling Matches...' : 'Auto-Schedule Matches'}
        </span>
        {scheduling && (
          <svg className="animate-spin h-5 w-5 relative z-10" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
          </svg>
        )}
      </button>

      {/* Error Modal */}
      {showError && errorDetails && (
        <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-[9999] w-full max-w-xl max-h-[90vh] overflow-y-auto p-4">
          <div className="relative bg-white rounded-2xl p-10 animate-slide-up border-2 border-gray-400">
              <button
                onClick={() => setShowError(false)}
                className="absolute top-6 right-6 text-gray-400 hover:text-gray-900 transition-colors z-10"
              >
                <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>

            <div className="flex items-start gap-5 mb-8">
              <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-red-500 to-red-600 flex items-center justify-center flex-shrink-0 shadow-lg">
                <AlertIcon className="w-10 h-10 text-white" />
              </div>
              <div className="flex-1">
                <h3 className="text-3xl font-bold text-gray-900 mb-3">Cannot Fit All Matches</h3>
                <p className="text-base text-gray-600 leading-relaxed">
                  Unable to schedule all matches within tournament constraints
                </p>
              </div>
            </div>

            <div className="space-y-5 mb-8">
              <div className="p-6 bg-gradient-to-br from-red-50 to-orange-50 rounded-2xl border-2 border-red-200">
                <div className="flex justify-between items-center mb-4">
                  <span className="text-base font-semibold text-gray-900">Matches Scheduled</span>
                  <span className="text-3xl font-bold text-red-600">{errorDetails.canFit} / {errorDetails.total}</span>
                </div>
                <div className="w-full bg-red-200 rounded-full h-4">
                  <div
                    className="bg-gradient-to-r from-red-500 to-red-600 h-4 rounded-full transition-all shadow-sm"
                    style={{ width: `${(errorDetails.canFit / errorDetails.total) * 100}%` }}
                  />
                </div>
              </div>

              {errorDetails.suggestion && (
                <div className="p-6 bg-gradient-to-br from-blue-50 to-indigo-50 rounded-2xl border-2 border-blue-200">
                  <p className="text-base font-semibold text-gray-900 mb-3">Suggestions</p>
                  <p className="text-base text-gray-700 leading-relaxed">{errorDetails.suggestion}</p>
                </div>
              )}
            </div>

            <div className="flex gap-4">
              <button
                onClick={() => setShowError(false)}
                className="flex-1 px-8 py-4 bg-gray-100 hover:bg-gray-200 text-gray-900 font-semibold rounded-xl transition-all text-lg"
              >
                Close
              </button>
              <button
                onClick={() => {
                  setShowError(false)
                }}
                className="flex-1 px-8 py-4 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white font-semibold rounded-xl transition-all shadow-lg text-lg"
              >
                Adjust Settings
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Success Modal */}
      {showSuccess && successDetails && (
        <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-[9999] w-full max-w-lg p-4">
          <div className="relative bg-white rounded-2xl p-10 animate-slide-up border-2 border-gray-400">
              <button
                onClick={() => setShowSuccess(false)}
                className="absolute top-6 right-6 text-gray-400 hover:text-gray-900 transition-colors z-10"
              >
                <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>

            <div className="flex items-start gap-5 mb-8">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-green-500 to-emerald-600 flex items-center justify-center flex-shrink-0 shadow-lg">
                <CheckIcon className="w-8 h-8 text-white" />
              </div>
              <div className="flex-1">
                <h3 className="text-3xl font-bold text-gray-900 mb-2">Schedule Complete</h3>
                <p className="text-base text-gray-600">
                  All matches have been scheduled successfully
                </p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-5 mb-8">
              <div className="p-5 bg-gradient-to-br from-blue-50 to-indigo-50 rounded-2xl border-2 border-blue-200">
                <div className="flex items-center gap-2 mb-2">
                  <CalendarIcon className="w-5 h-5 text-indigo-600" />
                  <span className="text-xs font-semibold text-indigo-600 uppercase tracking-wide">Matches</span>
                </div>
                <p className="text-3xl font-bold text-gray-900">{successDetails.scheduledMatches}</p>
              </div>

              <div className="p-5 bg-gradient-to-br from-purple-50 to-pink-50 rounded-2xl border-2 border-purple-200">
                <div className="flex items-center gap-2 mb-2">
                  <ClockIcon className="w-5 h-5 text-purple-600" />
                  <span className="text-xs font-semibold text-purple-600 uppercase tracking-wide">Days</span>
                </div>
                <p className="text-3xl font-bold text-gray-900">{successDetails.daysUsed}</p>
              </div>
            </div>

            <div className="p-5 bg-gray-50 rounded-2xl border border-gray-200 mb-8">
              <div className="flex items-center justify-between text-base mb-2">
                <span className="text-gray-600 font-medium">First Match</span>
                <span className="font-semibold text-gray-900">
                  {new Date(successDetails.firstMatchDate).toLocaleDateString('en-US', {
                    month: 'short', day: 'numeric', year: 'numeric'
                  })}
                </span>
              </div>
              <div className="flex items-center justify-between text-base">
                <span className="text-gray-600 font-medium">Last Match</span>
                <span className="font-semibold text-gray-900">
                  {new Date(successDetails.lastMatchDate).toLocaleDateString('en-US', {
                    month: 'short', day: 'numeric', year: 'numeric'
                  })}
                </span>
              </div>
            </div>

            <button
              onClick={() => setShowSuccess(false)}
              className="w-full px-8 py-4 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white font-semibold rounded-xl transition-all shadow-lg text-lg"
            >
              View Schedule
            </button>
          </div>
        </div>
      )}
    </>
  )
}

export default AutoScheduleButton
