import { useState, useEffect } from 'react'
import { useAuth } from '../context/AuthContext'
import { useNavigate } from 'react-router-dom'
import Navbar from '../components/Navbar'
import api from '../services/api'

const DashboardPage = () => {
  const { user, context } = useAuth()
  const navigate = useNavigate()
  const [stats, setStats] = useState({
    upcomingMatches: 0,
    activeTournaments: 0,
    eventsManaged: 0,
    totalRegistrations: 0
  })
  const [liveFeed, setLiveFeed] = useState([])
  const [recommendedTournaments, setRecommendedTournaments] = useState([])
  const [upcomingSchedule, setUpcomingSchedule] = useState([])
  const [trendingTournaments, setTrendingTournaments] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadDashboardData()
  }, [])

  const loadDashboardData = async () => {
    try {
      setLoading(true)

      // Fetch user registrations for stats
      const registrationsRes = await api.get('/users/me/registrations')
      const registrations = registrationsRes.data.registrations || []

      // Calculate upcoming matches
      const upcoming = registrations.filter(r =>
        r.event?.tournament?.status === 'OPEN' || r.event?.tournament?.status === 'ONGOING'
      )

      // Fetch all tournaments for recommendations and trending
      const tournamentsRes = await api.get('/tournaments')
      const allTournaments = tournamentsRes.data.tournaments || []

      // Filter open tournaments
      const openTournaments = allTournaments.filter(t => t.status === 'OPEN')

      // Get user's sports from profile for recommendations
      const userSports = user?.sports || []
      const userCity = user?.city || ''

      // Recommended tournaments (filter by user profile - city and sports)
      const recommended = openTournaments
        .filter(t => {
          // Prioritize tournaments in user's city
          const cityMatch = userCity && t.city &&
            t.city.toLowerCase().trim() === userCity.toLowerCase().trim()

          // Match user's sports interests
          const sportMatch = userSports.length > 0 &&
            userSports.some(s => s.toLowerCase() === t.sport.toLowerCase())

          // Show only if city matches OR sport matches
          return cityMatch || sportMatch
        })
        .sort((a, b) => {
          // Prioritize city matches over sport matches
          const aCityMatch = userCity && a.city &&
            a.city.toLowerCase().trim() === userCity.toLowerCase().trim()
          const bCityMatch = userCity && b.city &&
            b.city.toLowerCase().trim() === userCity.toLowerCase().trim()

          if (aCityMatch && !bCityMatch) return -1
          if (!aCityMatch && bCityMatch) return 1
          return 0
        })
        .slice(0, 3)

      // Trending tournaments (sort by participant count)
      const trending = [...allTournaments]
        .filter(t => t.status === 'OPEN')
        .sort((a, b) => (b.participantCount || 0) - (a.participantCount || 0))
        .slice(0, 5)

      // Build live feed with accurate timestamps
      const feed = []
      const now = new Date()

      // Helper to format relative time
      const getRelativeTime = (date) => {
        const diffMs = now - new Date(date)
        const diffMins = Math.floor(diffMs / 60000)
        const diffHours = Math.floor(diffMs / 3600000)
        const diffDays = Math.floor(diffMs / 86400000)

        if (diffMins < 1) return 'Just now'
        if (diffMins < 60) return `${diffMins}m ago`
        if (diffHours < 24) return `${diffHours}h ago`
        if (diffDays < 7) return `${diffDays}d ago`
        return new Date(date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
      }

      // Add recent tournaments (created in last 7 days)
      allTournaments
        .filter(t => (now - new Date(t.createdAt)) < 7 * 24 * 60 * 60 * 1000)
        .slice(0, 2)
        .forEach(t => {
          feed.push({
            type: 'tournament',
            icon: '🎾',
            message: `New tournament: ${t.name}`,
            time: getRelativeTime(t.createdAt),
            tournament: t
          })
        })

      // Add registration updates
      if (upcoming.length > 0) {
        const latestReg = upcoming[0]
        feed.push({
          type: 'registration',
          icon: '✅',
          message: `You're registered for ${upcoming.length} upcoming event${upcoming.length > 1 ? 's' : ''}`,
          time: latestReg.createdAt ? getRelativeTime(latestReg.createdAt) : 'Recently'
        })
      }

      // Add closing deadlines
      openTournaments.slice(0, 2).forEach(t => {
        const deadline = new Date(t.registrationDeadline)
        const now = new Date()
        const hoursLeft = Math.floor((deadline - now) / (1000 * 60 * 60))

        if (hoursLeft > 0 && hoursLeft < 48) {
          feed.push({
            type: 'deadline',
            icon: '⏰',
            message: `Registration closing in ${hoursLeft} hours - ${t.name}`,
            time: `${hoursLeft}h left`,
            tournament: t
          })
        }
      })

      // Build schedule
      const schedule = upcoming.slice(0, 5).map(reg => ({
        time: new Date(reg.event.tournament.startDate).toLocaleString('en-US', {
          month: 'short',
          day: 'numeric',
          hour: '2-digit',
          minute: '2-digit'
        }),
        title: reg.event.name,
        tournament: reg.event.tournament.name,
        venue: reg.event.tournament.venueName
      }))

      setStats({
        upcomingMatches: upcoming.length,
        activeTournaments: new Set(upcoming.map(r => r.event.tournament.id)).size,
        eventsManaged: context?.orgs?.length || 0,
        totalRegistrations: registrations.length
      })

      setLiveFeed(feed)
      setRecommendedTournaments(recommended)
      setUpcomingSchedule(schedule)
      setTrendingTournaments(trending)

    } catch (err) {
      console.error('Error loading dashboard:', err)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-primary-50/20">
        <Navbar />
        <div className="flex items-center justify-center h-[calc(100vh-4rem)]">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-primary-50/20">
      <Navbar />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Welcome back, {user?.firstName}
          </h1>
          <p className="text-gray-600">Here's what's happening with your tournaments</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <div className="glass-card rounded-xl p-6 hover:shadow-lg transition-all cursor-pointer" onClick={() => navigate('/matches')}>
            <div className="text-3xl font-bold text-primary-600 mb-2">{stats.upcomingMatches}</div>
            <div className="text-sm font-medium text-gray-600">Upcoming Matches</div>
          </div>
          <div className="glass-card rounded-xl p-6 hover:shadow-lg transition-all cursor-pointer" onClick={() => navigate('/browse')}>
            <div className="text-3xl font-bold text-success-600 mb-2">{stats.activeTournaments}</div>
            <div className="text-sm font-medium text-gray-600">Active Tournaments</div>
          </div>
          <div className="glass-card rounded-xl p-6 hover:shadow-lg transition-all cursor-pointer" onClick={() => navigate('/manage')}>
            <div className="text-3xl font-bold text-warning-600 mb-2">{stats.eventsManaged}</div>
            <div className="text-sm font-medium text-gray-600">Organizations</div>
          </div>
          <div className="glass-card rounded-xl p-6 hover:shadow-lg transition-all">
            <div className="text-3xl font-bold text-gray-900 mb-2">{stats.totalRegistrations}</div>
            <div className="text-sm font-medium text-gray-600">Total Registrations</div>
          </div>
        </div>

        {/* Main Content Grid */}
        <div className="grid lg:grid-cols-2 gap-6 mb-6">
          {/* Live Feed */}
          <div className="glass-card rounded-2xl p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2">
                <span className="w-2 h-2 bg-danger-600 rounded-full animate-pulse"></span>
                Live Feed
              </h2>
            </div>

            {liveFeed.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <p>No recent activity</p>
              </div>
            ) : (
              <div className="space-y-4">
                {liveFeed.map((item, idx) => (
                  <div
                    key={idx}
                    className="flex items-start gap-3 p-4 bg-gray-50/50 rounded-lg hover:bg-gray-100/50 transition-all cursor-pointer"
                    onClick={() => item.tournament && navigate(`/tournaments/${item.tournament.id}`)}
                  >
                    <span className="text-2xl">{item.icon}</span>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-900">{item.message}</p>
                      <p className="text-xs text-gray-500 mt-1">{item.time}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Recommended Tournaments */}
          <div className="glass-card rounded-2xl p-6">
            <h2 className="text-xl font-bold text-gray-900 mb-2 flex items-center gap-2">
              ✨ Recommended For You
            </h2>
            <p className="text-sm text-gray-600 mb-6">
              Based on your profile • {user?.city || 'Your location'}
            </p>

            {recommendedTournaments.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-gray-500 mb-4">No recommendations yet</p>
                <button
                  onClick={() => navigate('/browse')}
                  className="px-6 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-all"
                >
                  Browse All Tournaments
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                {recommendedTournaments.map((tournament) => (
                  <div
                    key={tournament.id}
                    className="border border-gray-200 rounded-xl p-4 hover:border-primary-300 hover:shadow-md transition-all cursor-pointer"
                    onClick={() => navigate(`/tournaments/${tournament.id}`)}
                  >
                    <h3 className="font-semibold text-gray-900 mb-2">{tournament.name}</h3>
                    <div className="flex items-center gap-4 text-sm text-gray-600">
                      <span>📍 {tournament.city}</span>
                      <span>🎾 {tournament.sport.replace('-', ' ')}</span>
                    </div>
                    {tournament.participantCount > 0 && (
                      <p className="text-sm text-primary-600 font-medium mt-2">
                        {tournament.participantCount} registered
                      </p>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Quick Actions Carousel */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold text-gray-900">Quick Actions</h2>
          </div>
          <div className="relative">
            <div className="flex gap-6 overflow-x-auto pb-4 snap-x snap-mandatory scroll-smooth" style={{ scrollbarWidth: 'thin' }}>
              <div
                className="min-w-[240px] snap-start glass-card rounded-2xl p-8 hover:shadow-xl transition-all cursor-pointer bg-gradient-to-br from-primary-500 to-primary-600 text-white transform hover:scale-105"
                onClick={() => navigate('/browse')}
              >
                <div className="text-4xl mb-4">🔍</div>
                <div className="font-bold text-xl mb-2">Find Tournaments</div>
                <div className="text-sm text-primary-100">Browse & register for events</div>
              </div>

              {context?.orgs?.length > 0 && (
                <div
                  className="min-w-[240px] snap-start glass-card rounded-2xl p-8 hover:shadow-xl transition-all cursor-pointer bg-gradient-to-br from-success-500 to-success-600 text-white transform hover:scale-105"
                  onClick={() => navigate('/manage')}
                >
                  <div className="text-4xl mb-4">🏆</div>
                  <div className="font-bold text-xl mb-2">Manage Events</div>
                  <div className="text-sm text-success-100">Your organizations</div>
                </div>
              )}

              <div
                className="min-w-[240px] snap-start glass-card rounded-2xl p-8 hover:shadow-xl transition-all cursor-pointer bg-gradient-to-br from-warning-500 to-warning-600 text-white transform hover:scale-105"
                onClick={() => navigate('/matches')}
              >
                <div className="text-4xl mb-4">📅</div>
                <div className="font-bold text-xl mb-2">My Matches</div>
                <div className="text-sm text-warning-100">View your schedule</div>
              </div>

              <div
                className="min-w-[240px] snap-start glass-card rounded-2xl p-8 hover:shadow-xl transition-all cursor-pointer bg-gradient-to-br from-gray-700 to-gray-800 text-white transform hover:scale-105"
                onClick={() => navigate('/profile')}
              >
                <div className="text-4xl mb-4">👤</div>
                <div className="font-bold text-xl mb-2">My Profile</div>
                <div className="text-sm text-gray-300">Edit your details</div>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Grid */}
        <div className="grid lg:grid-cols-2 gap-6">
          {/* Your Schedule */}
          <div className="glass-card rounded-2xl p-6">
            <h2 className="text-xl font-bold text-gray-900 mb-6 flex items-center gap-2">
              📅 Your Schedule
            </h2>

            {upcomingSchedule.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-gray-500 mb-4">No upcoming matches</p>
                <button
                  onClick={() => navigate('/browse')}
                  className="px-6 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-all"
                >
                  Register for Events
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                {upcomingSchedule.map((match, idx) => (
                  <div key={idx} className="border-l-4 border-primary-600 pl-4 py-2">
                    <div className="font-semibold text-gray-900">{match.title}</div>
                    <div className="text-sm text-gray-600">{match.tournament}</div>
                    <div className="text-xs text-gray-500 mt-1">
                      {match.time} • {match.venue}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Trending Tournaments */}
          <div className="glass-card rounded-2xl p-6">
            <h2 className="text-xl font-bold text-gray-900 mb-6 flex items-center gap-2">
              🔥 Trending Now
            </h2>

            {trendingTournaments.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <p>No trending tournaments</p>
              </div>
            ) : (
              <div className="space-y-3">
                {trendingTournaments.map((tournament, idx) => (
                  <div
                    key={tournament.id}
                    className="flex items-center gap-3 p-3 hover:bg-gray-50 rounded-lg transition-all cursor-pointer"
                    onClick={() => navigate(`/tournaments/${tournament.id}`)}
                  >
                    <div className="text-xl font-bold text-primary-600 w-8">{idx + 1}</div>
                    <div className="flex-1 min-w-0">
                      <div className="font-semibold text-gray-900 truncate">{tournament.name}</div>
                      <div className="text-sm text-gray-600">{tournament.city}</div>
                    </div>
                    <div className="text-sm font-medium text-primary-600">
                      {tournament.participantCount || 0}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  )
}

export default DashboardPage
