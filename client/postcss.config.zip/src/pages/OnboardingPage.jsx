import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import api from '../services/api'

export default function OnboardingPage() {
  const { user, refreshContext } = useAuth()
  const navigate = useNavigate()
  const [step, setStep] = useState(1) // 1: profile, 2: choice, 3: org name
  const [choice, setChoice] = useState(null) // 'org' | 'player'
  const [orgName, setOrgName] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  // Profile fields
  const [profile, setProfile] = useState({
    dob: '',
    gender: '',
    city: '',
    phone: '',
    bio: '',
    sports: []
  })

  const sportsList = ['Badminton', 'Tennis', 'Table Tennis', 'Squash', 'Pickleball', 'Padel']

  const toggleSport = (sport) => {
    setProfile(prev => ({
      ...prev,
      sports: prev.sports.includes(sport)
        ? prev.sports.filter(s => s !== sport)
        : [...prev.sports, sport]
    }))
  }

  const handleProfileNext = () => {
    if (!profile.dob || !profile.gender || !profile.city) {
      setError('Please fill in all required fields')
      return
    }
    setError('')
    setStep(2)
  }

  const handleCreateOrg = async () => {
    if (!orgName.trim()) return setError('Please enter an organization name')
    setLoading(true)
    setError('')
    try {
      // Save profile first
      await api.patch('/auth/profile', profile)
      // Create organization
      await api.post('/orgs', { name: orgName })
      await refreshContext()
      navigate('/dashboard')
    } catch (err) {
      setError(err.response?.data?.error || 'Something went wrong')
    } finally {
      setLoading(false)
    }
  }

  const handleJoinAsPlayer = async () => {
    setLoading(true)
    try {
      // Save profile first
      await api.patch('/auth/profile', profile)
      await api.patch('/auth/onboarding', { onboardingComplete: true })
      await refreshContext()
      navigate('/dashboard')
    } catch {
      navigate('/dashboard')
    } finally {
      setLoading(false)
    }
  }

  // Step 1: Profile Setup
  if (step === 1) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-primary-50/20 flex items-center justify-center px-4 py-12">
        <div className="w-full max-w-2xl animate-fade-in">
          <div className="text-center mb-10">
            <h1 className="text-4xl font-bold text-gray-900 mb-2">
              Welcome, {user?.firstName}
            </h1>
            <p className="text-gray-600">
              Let's set up your profile
            </p>
          </div>

          <div className="glass-card rounded-2xl p-8">
            <div className="space-y-6">
              {/* Date of Birth */}
              <div>
                <label className="block text-sm font-medium text-gray-900 mb-2">
                  Date of Birth *
                </label>
                <input
                  type="date"
                  value={profile.dob}
                  onChange={e => setProfile({ ...profile, dob: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent outline-none bg-white"
                  required
                />
              </div>

              {/* Gender */}
              <div>
                <label className="block text-sm font-medium text-gray-900 mb-2">
                  Gender *
                </label>
                <select
                  value={profile.gender}
                  onChange={e => setProfile({ ...profile, gender: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent outline-none bg-white"
                  required
                >
                  <option value="">Select gender</option>
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                  <option value="Other">Other</option>
                </select>
              </div>

              {/* City */}
              <div>
                <label className="block text-sm font-medium text-gray-900 mb-2">
                  City *
                </label>
                <input
                  type="text"
                  value={profile.city}
                  onChange={e => setProfile({ ...profile, city: e.target.value })}
                  placeholder="e.g., Mumbai"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent outline-none bg-white"
                  required
                />
              </div>

              {/* Phone */}
              <div>
                <label className="block text-sm font-medium text-gray-900 mb-2">
                  Phone Number
                </label>
                <input
                  type="tel"
                  value={profile.phone}
                  onChange={e => setProfile({ ...profile, phone: e.target.value })}
                  placeholder="+91 98765 43210"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent outline-none bg-white"
                />
              </div>

              {/* Sports Interests */}
              <div>
                <label className="block text-sm font-medium text-gray-900 mb-3">
                  Sports You Play (Select all that apply)
                </label>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {sportsList.map(sport => (
                    <button
                      key={sport}
                      type="button"
                      onClick={() => toggleSport(sport)}
                      className={`px-4 py-3 rounded-lg border-2 font-medium transition-all ${
                        profile.sports.includes(sport)
                          ? 'border-primary-500 bg-primary-50 text-primary-700'
                          : 'border-gray-200 bg-white text-gray-700 hover:border-gray-300'
                      }`}
                    >
                      {sport}
                    </button>
                  ))}
                </div>
              </div>

              {/* Bio */}
              <div>
                <label className="block text-sm font-medium text-gray-900 mb-2">
                  Bio / About You
                </label>
                <textarea
                  value={profile.bio}
                  onChange={e => setProfile({ ...profile, bio: e.target.value })}
                  placeholder="Tell us a bit about yourself and your sports journey..."
                  rows={4}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent outline-none bg-white resize-none"
                />
              </div>
            </div>

            {error && (
              <div className="mt-6 p-4 bg-danger-50 border border-danger-200 rounded-lg">
                <p className="text-sm text-danger-700 font-medium">{error}</p>
              </div>
            )}

            <button
              onClick={handleProfileNext}
              className="w-full mt-8 px-6 py-3.5 bg-primary-600 hover:bg-primary-700 text-white font-semibold rounded-lg transition-all shadow-md hover:shadow-lg flex items-center justify-center gap-2"
            >
              <span>Continue</span>
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
              </svg>
            </button>
          </div>
        </div>
      </div>
    )
  }

  // Step 2: Choose Path
  if (step === 2) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-primary-50/20 flex items-center justify-center px-4 py-12">
        <div className="w-full max-w-lg animate-fade-in">
          <div className="text-center mb-10">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">
              How will you use StepOut2Play?
            </h1>
            <p className="text-gray-600">
              Choose your primary role (you can do both later)
            </p>
          </div>

          <div className="space-y-4 mb-8">
            {/* Organize Tournaments */}
            <button
              onClick={() => {
                setChoice('org')
                setStep(3)
              }}
              className="w-full p-6 rounded-2xl border-2 border-gray-200 bg-white hover:border-primary-300 hover:shadow-md transition-all text-left"
            >
              <div className="flex items-start gap-4">
                <div className="flex-1">
                  <h3 className="text-xl font-bold text-gray-900 mb-2">
                    Organize Tournaments
                  </h3>
                  <p className="text-sm text-gray-600 leading-relaxed">
                    Create an organization to manage tournaments, events, and players
                  </p>
                </div>
                <svg className="w-6 h-6 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                </svg>
              </div>
            </button>

            {/* Join as Player */}
            <button
              onClick={() => {
                setChoice('player')
                handleJoinAsPlayer()
              }}
              className="w-full p-6 rounded-2xl border-2 border-gray-200 bg-white hover:border-primary-300 hover:shadow-md transition-all text-left"
            >
              <div className="flex items-start gap-4">
                <div className="flex-1">
                  <h3 className="text-xl font-bold text-gray-900 mb-2">
                    Play in Tournaments
                  </h3>
                  <p className="text-sm text-gray-600 leading-relaxed">
                    Browse events, register for tournaments, and track your matches
                  </p>
                </div>
                <svg className="w-6 h-6 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                </svg>
              </div>
            </button>
          </div>

          <button
            onClick={() => setStep(1)}
            className="w-full px-6 py-3 text-gray-600 hover:text-gray-900 font-medium transition-all"
          >
            Back to Profile
          </button>
        </div>
      </div>
    )
  }

  // Step 3: Organization Name
  if (step === 3) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-primary-50/20 flex items-center justify-center px-4 py-12">
        <div className="w-full max-w-lg animate-fade-in">
          <div className="text-center mb-10">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">
              Create Your Organization
            </h1>
            <p className="text-gray-600">
              Choose a name for your organization
            </p>
          </div>

          <div className="glass-card rounded-2xl p-8">
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-900 mb-2">
                Organization Name *
              </label>
              <input
                type="text"
                value={orgName}
                onChange={e => setOrgName(e.target.value)}
                placeholder="e.g., NBC Sports Academy"
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent outline-none bg-white"
                onKeyDown={e => e.key === 'Enter' && handleCreateOrg()}
                autoFocus
              />
            </div>

            {error && (
              <div className="mb-6 p-4 bg-danger-50 border border-danger-200 rounded-lg">
                <p className="text-sm text-danger-700 font-medium">{error}</p>
              </div>
            )}

            <div className="flex gap-3">
              <button
                onClick={() => setStep(2)}
                className="px-6 py-3 text-gray-600 hover:text-gray-900 font-medium transition-all"
              >
                Back
              </button>
              <button
                onClick={handleCreateOrg}
                disabled={loading}
                className="flex-1 px-6 py-3.5 bg-primary-600 hover:bg-primary-700 text-white font-semibold rounded-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 shadow-md hover:shadow-lg"
              >
                {loading ? (
                  <>
                    <svg className="animate-spin h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    <span>Creating...</span>
                  </>
                ) : (
                  <span>Create Organization</span>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    )
  }
}
