import { useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { useEffect } from 'react'

const TrophyIcon = (props) => (
  <svg {...props} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z" />
  </svg>
)

const GridIcon = (props) => (
  <svg {...props} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 5a1 1 0 011-1h4a1 1 0 011 1v7a1 1 0 01-1 1H5a1 1 0 01-1-1V5zM14 5a1 1 0 011-1h4a1 1 0 011 1v7a1 1 0 01-1 1h-4a1 1 0 01-1-1V5zM4 16a1 1 0 011-1h4a1 1 0 011 1v3a1 1 0 01-1 1H5a1 1 0 01-1-1v-3zM14 16a1 1 0 011-1h4a1 1 0 011 1v3a1 1 0 01-1 1h-4a1 1 0 01-1-1v-3z" />
  </svg>
)

const UsersIcon = (props) => (
  <svg {...props} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
  </svg>
)

const CalendarIcon = (props) => (
  <svg {...props} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
  </svg>
)

const ChartIcon = (props) => (
  <svg {...props} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
  </svg>
)

const LightningIcon = (props) => (
  <svg {...props} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
  </svg>
)

const CheckIcon = (props) => (
  <svg {...props} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
  </svg>
)

const LandingPage = () => {
  const navigate = useNavigate()
  const { user } = useAuth()

  useEffect(() => {
    // If user is already logged in, redirect to dashboard
    if (user) {
      navigate('/dashboard')
    }
  }, [user, navigate])

  const sports = [
    { name: 'Badminton', icon: '🏸' },
    { name: 'Tennis', icon: '🎾' },
    { name: 'Table Tennis', icon: '🏓' },
    { name: 'Squash', icon: '🎾' },
    { name: 'Pickleball', icon: '🏓' }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-primary-50/20">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 glass-card border-b border-gray-200/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-primary-500 to-primary-600 flex items-center justify-center">
                <span className="text-2xl font-black text-white">S</span>
              </div>
              <span className="text-xl font-bold text-gray-900">StepOut2Play</span>
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={() => navigate('/login')}
                className="px-5 py-2 text-gray-700 font-medium hover:text-gray-900 transition-colors"
              >
                Log In
              </button>
              <button
                onClick={() => navigate('/signup')}
                className="px-6 py-2.5 bg-primary-600 hover:bg-primary-700 text-white font-medium rounded-lg shadow-sm hover:shadow-md transition-all"
              >
                Sign Up
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 lg:py-28">
        <div className="absolute inset-0 bg-gradient-to-br from-primary-50/50 via-white to-success-50/30"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-4xl mx-auto">
            <h1 className="text-5xl lg:text-7xl font-black text-gray-900 mb-6 tracking-tight animate-slide-up leading-tight">
              Tournament Management
              <span className="block text-primary-600 mt-3">Made Simple</span>
            </h1>
            <p className="text-xl lg:text-2xl text-gray-600 mb-4 max-w-3xl mx-auto animate-slide-up font-medium" style={{ animationDelay: '0.1s' }}>
              Badminton · Tennis · Table Tennis · Squash · Pickleball · Padel
            </p>
            <p className="text-base text-gray-500 mb-10 max-w-2xl mx-auto animate-slide-up" style={{ animationDelay: '0.15s' }}>
              Powered by automatic bracket generation
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 animate-slide-up" style={{ animationDelay: '0.2s' }}>
              <button
                onClick={() => navigate('/signup')}
                className="w-full sm:w-auto px-10 py-4 bg-primary-600 hover:bg-primary-700 text-white font-bold rounded-lg shadow-lg hover:shadow-xl transition-all text-lg uppercase tracking-wider"
              >
                Get Started
              </button>
              <button
                onClick={() => navigate('/browse')}
                className="w-full sm:w-auto px-10 py-4 bg-gray-900 hover:bg-gray-800 text-white font-bold rounded-lg shadow-lg hover:shadow-xl transition-all text-lg uppercase tracking-wider"
              >
                Browse Tournaments
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* USP Section - Bracket Generation */}
      <section className="py-20 bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 text-white relative overflow-hidden">
        <div className="absolute inset-0 opacity-5">
          <div className="absolute inset-0" style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)', backgroundSize: '40px 40px' }}></div>
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl lg:text-6xl font-black mb-6 tracking-tight">
              Automatic Bracket Generation
            </h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto font-medium">
              Stop spending hours creating tournament brackets manually. Our intelligent system generates perfect brackets in seconds.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mt-12">
            <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-xl p-8">
              <div className="w-14 h-14 bg-primary-600 rounded-lg flex items-center justify-center mb-6">
                <LightningIcon className="w-7 h-7 text-white" />
              </div>
              <h3 className="text-2xl font-bold mb-3">Instant Generation</h3>
              <p className="text-gray-300 leading-relaxed">
                Create brackets for 4, 8, 16, 32, or any number of players in milliseconds. No manual work required.
              </p>
            </div>

            <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-xl p-8">
              <div className="w-14 h-14 bg-primary-600 rounded-lg flex items-center justify-center mb-6">
                <GridIcon className="w-7 h-7 text-white" />
              </div>
              <h3 className="text-2xl font-bold mb-3">Smart Seeding</h3>
              <p className="text-gray-300 leading-relaxed">
                Automatic seeding based on rankings, random draws, or custom rules. Fair matchups every time.
              </p>
            </div>

            <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-xl p-8">
              <div className="w-14 h-14 bg-primary-600 rounded-lg flex items-center justify-center mb-6">
                <ChartIcon className="w-7 h-7 text-white" />
              </div>
              <h3 className="text-2xl font-bold mb-3">Live Updates</h3>
              <p className="text-gray-300 leading-relaxed">
                Brackets update in real-time as matches are played. Players always know when and where to compete.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Two Journeys Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl lg:text-6xl font-black text-gray-900 mb-6 tracking-tight">
              For Players & Organizers
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto font-medium">
              Compete in tournaments or organize them. You choose your path.
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-8 items-stretch">
            {/* Player Journey */}
            <div className="glass-card rounded-2xl p-10 hover:shadow-xl transition-all border border-gray-200 flex flex-col">
              <h3 className="text-3xl font-bold text-gray-900 mb-4">Players</h3>
              <p className="text-gray-600 mb-8 text-lg">
                Find tournaments, register, and track your progress.
              </p>
              <ul className="space-y-4 mb-8 flex-grow">
                <li className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-success-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <CheckIcon className="w-4 h-4 text-success-600" />
                  </div>
                  <span className="text-gray-700"><strong>Browse tournaments</strong> by sport, location, and date</span>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-success-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <CheckIcon className="w-4 h-4 text-success-600" />
                  </div>
                  <span className="text-gray-700"><strong>Register for events</strong> in singles, doubles, or mixed</span>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-success-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <CheckIcon className="w-4 h-4 text-success-600" />
                  </div>
                  <span className="text-gray-700"><strong>Track your matches</strong> and view live brackets</span>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-success-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <CheckIcon className="w-4 h-4 text-success-600" />
                  </div>
                  <span className="text-gray-700"><strong>Build your profile</strong> with tournament history and stats</span>
                </li>
              </ul>
              <button
                onClick={() => navigate('/signup')}
                className="w-full px-6 py-3 bg-primary-600 hover:bg-primary-700 text-white font-semibold rounded-lg transition-all uppercase tracking-wide mt-auto"
              >
                Start Playing
              </button>
            </div>

            {/* Organizer Journey */}
            <div className="glass-card rounded-2xl p-10 hover:shadow-xl transition-all border border-gray-200 flex flex-col">
              <h3 className="text-3xl font-bold text-gray-900 mb-4">Organizers</h3>
              <p className="text-gray-600 mb-8 text-lg">
                Create tournaments and generate brackets automatically.
              </p>
              <ul className="space-y-4 mb-8 flex-grow">
                <li className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-success-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <CheckIcon className="w-4 h-4 text-success-600" />
                  </div>
                  <span className="text-gray-700"><strong>Create tournaments</strong> with custom formats and rules</span>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-success-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <CheckIcon className="w-4 h-4 text-success-600" />
                  </div>
                  <span className="text-gray-700"><strong>Manage registrations</strong> and participant details</span>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-success-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <CheckIcon className="w-4 h-4 text-success-600" />
                  </div>
                  <span className="text-gray-700"><strong>Generate brackets</strong> automatically—no manual work</span>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-success-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <CheckIcon className="w-4 h-4 text-success-600" />
                  </div>
                  <span className="text-gray-700"><strong>Real-time scoring</strong> and live bracket updates</span>
                </li>
              </ul>
              <button
                onClick={() => navigate('/signup')}
                className="w-full px-6 py-3 bg-gray-900 hover:bg-gray-800 text-white font-semibold rounded-lg transition-all uppercase tracking-wide mt-auto"
              >
                Start Organizing
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-20 bg-gradient-to-br from-gray-50 to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl lg:text-6xl font-black text-gray-900 mb-6 tracking-tight">
              Everything You Need
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto font-medium">
              Professional tournament management tools.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="glass-card rounded-2xl p-8">
              <div className="w-12 h-12 bg-primary-100 rounded-xl flex items-center justify-center mb-5">
                <CalendarIcon className="w-6 h-6 text-primary-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Event Categories</h3>
              <p className="text-gray-600">
                Create events with age and gender categories: Open Men's, U19 Boys, Women's, Veterans 40+, and more.
              </p>
            </div>

            <div className="glass-card rounded-2xl p-8">
              <div className="w-12 h-12 bg-success-100 rounded-xl flex items-center justify-center mb-5">
                <UsersIcon className="w-6 h-6 text-success-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Team Management</h3>
              <p className="text-gray-600">
                Singles, Doubles, and Mixed Doubles support. Invite team members and manage your organization together.
              </p>
            </div>

            <div className="glass-card rounded-2xl p-8">
              <div className="w-12 h-12 bg-warning-100 rounded-xl flex items-center justify-center mb-5">
                <ChartIcon className="w-6 h-6 text-warning-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Live Scoring</h3>
              <p className="text-gray-600">
                Real-time match scores and bracket updates. Players and spectators stay informed throughout the tournament.
              </p>
            </div>

            <div className="glass-card rounded-2xl p-8">
              <div className="w-12 h-12 bg-danger-100 rounded-xl flex items-center justify-center mb-5">
                <TrophyIcon className="w-6 h-6 text-danger-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Multiple Formats</h3>
              <p className="text-gray-600">
                Support for Bracket, Round Robin, Knockout, and League formats. Choose what works best for your event.
              </p>
            </div>

            <div className="glass-card rounded-2xl p-8">
              <div className="w-12 h-12 bg-primary-100 rounded-xl flex items-center justify-center mb-5">
                <GridIcon className="w-6 h-6 text-primary-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">6 Sports Supported</h3>
              <p className="text-gray-600">
                Badminton, Tennis, Table Tennis, Squash, Pickleball, and Padel. All racket sports in one platform.
              </p>
            </div>

            <div className="glass-card rounded-2xl p-8">
              <div className="w-12 h-12 bg-success-100 rounded-xl flex items-center justify-center mb-5">
                <LightningIcon className="w-6 h-6 text-success-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Quick Setup</h3>
              <p className="text-gray-600">
                Create a tournament in under 5 minutes. Simple forms, smart defaults, and instant publication.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary-600 to-primary-700"></div>
        <div className="absolute inset-0 opacity-5" style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)', backgroundSize: '32px 32px' }}></div>
        <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl lg:text-6xl font-black text-white mb-6 tracking-tight">
            Ready to Get Started?
          </h2>
          <p className="text-xl text-primary-50 mb-10 max-w-2xl mx-auto font-medium">
            Join players and organizers using StepOut2Play.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <button
              onClick={() => navigate('/signup')}
              className="w-full sm:w-auto px-10 py-4 bg-white hover:bg-gray-50 text-primary-700 font-bold rounded-lg shadow-lg hover:shadow-xl transition-all text-lg uppercase tracking-wider"
            >
              Get Started
            </button>
            <button
              onClick={() => navigate('/browse')}
              className="w-full sm:w-auto px-10 py-4 bg-gray-900 hover:bg-gray-800 text-white font-bold rounded-lg shadow-lg hover:shadow-xl transition-all text-lg uppercase tracking-wider"
            >
              Browse Tournaments
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-400 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center gap-2 mb-4 md:mb-0">
              <div className="w-8 h-8 rounded-lg bg-primary-600 flex items-center justify-center">
                <span className="text-xl font-black text-white">S</span>
              </div>
              <span className="text-lg font-bold text-white">StepOut2Play</span>
            </div>
            <div className="text-center md:text-right">
              <p className="text-sm">© 2026 StepOut2Play. All rights reserved.</p>
              <p className="text-sm mt-1">Making tournament management effortless.</p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}

export default LandingPage
