import { useState, useEffect } from 'react'
import { useAuth } from '../context/AuthContext'
import { useNavigate } from 'react-router-dom'
import Navbar from '../components/Navbar'
import EmptyState from '../components/EmptyState'
import StatCard from '../components/StatCard'
import CTACard from '../components/CTACard'
import OrganizationCard from '../components/OrganizationCard'
import CreateOrganizationModal from '../components/CreateOrganizationModal'
import api from '../services/api'

// Icon components
const BuildingIcon = (props) => (
  <svg {...props} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
  </svg>
)

const TrophyIcon = (props) => (
  <svg {...props} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z" />
  </svg>
)

const UsersIcon = (props) => (
  <svg {...props} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
  </svg>
)

const CalendarIcon = (props) => (
  <svg {...props} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
  </svg>
)

const SearchIcon = (props) => (
  <svg {...props} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
  </svg>
)

const PlayIcon = (props) => (
  <svg {...props} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
)

const PlusIcon = (props) => (
  <svg {...props} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
  </svg>
)

const DashboardPage = () => {
  const { user, context, refreshContext } = useAuth()
  const navigate = useNavigate()
  const [organizations, setOrganizations] = useState([])
  const [registrations, setRegistrations] = useState([])
  const [loading, setLoading] = useState(true)
  const [isCreateOrgModalOpen, setIsCreateOrgModalOpen] = useState(false)

  useEffect(() => {
    const loadDashboardData = async () => {
      try {
        setOrganizations(context?.orgs || [])

        // Fetch user's registrations
        const response = await api.get('/users/me/registrations')
        if (response.data.success) {
          setRegistrations(response.data.registrations)
        }
      } catch (err) {
        console.error('Error loading registrations:', err)
      } finally {
        setLoading(false)
      }
    }

    loadDashboardData()
  }, [context])

  const handleCreateOrganization = () => {
    setIsCreateOrgModalOpen(true)
  }

  const handleOrgCreated = async (newOrg) => {
    await refreshContext()
    setOrganizations([...organizations, newOrg])
  }

  const handleBrowseTournaments = () => {
    navigate('/browse')
  }

  const handleCreateTournament = () => {
    // TODO: Create tournament modal
    alert('Create Tournament modal - Coming soon')
  }

  const handleViewOrg = (org) => {
    navigate(`/manage/org/${org.id}`)
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
        <Navbar />
        <div className="flex items-center justify-center h-[calc(100vh-4rem)]">
          <div className="flex flex-col items-center gap-4">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
            <p className="text-sm text-gray-500">Loading your dashboard...</p>
          </div>
        </div>
      </div>
    )
  }

  const hasOrganizations = organizations.length > 0
  const hasRegistrations = registrations.length > 0
  const isNewUser = !hasOrganizations && !hasRegistrations

  // New user - show both journeys equally
  if (isNewUser) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-primary-50/20">
        <Navbar />
        <main className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          {/* Hero Section - Role Neutral */}
          <div className="text-center mb-16 animate-fade-in">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-primary-50 border border-primary-100 rounded-full text-primary-700 text-sm font-medium mb-6">
              <span className="w-2 h-2 bg-primary-500 rounded-full animate-pulse"></span>
              Welcome to StepOut2Play
            </div>
            <h1 className="text-5xl font-bold text-gray-900 mb-4 tracking-tight">
              Welcome, {user?.firstName}
            </h1>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Play in tournaments or organize them. You choose your path—or do both.
            </p>
          </div>

          {/* Two Equal Primary Journeys */}
          <div className="grid md:grid-cols-2 gap-6 mb-16 animate-slide-up">
            <CTACard
              icon={PlayIcon}
              title="Join Tournaments"
              description="Browse upcoming tournaments, register for events, and compete with players in your area."
              buttonText="Browse Tournaments"
              onClick={handleBrowseTournaments}
              variant="primary"
            />
            <CTACard
              icon={BuildingIcon}
              title="Organize Tournaments"
              description="Create your organization and start managing professional tournaments with ease."
              buttonText="Create Organization"
              onClick={handleCreateOrganization}
              variant="primary"
            />
          </div>

          {/* Features - Both Perspectives */}
          <div className="glass-card rounded-2xl p-8 md:p-10">
            <h2 className="text-2xl font-bold text-gray-900 mb-8 text-center">
              For players and organizers
            </h2>
            <div className="grid md:grid-cols-2 gap-8">
              {/* Player Features */}
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-4">As a Player</h3>
                <ul className="space-y-3">
                  <li className="flex items-start gap-3">
                    <div className="w-5 h-5 rounded-full bg-primary-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                      <svg className="w-3 h-3 text-primary-600" fill="currentColor" viewBox="0 0 12 12">
                        <path d="M10 3L4.5 8.5L2 6" stroke="currentColor" strokeWidth="2" fill="none"/>
                      </svg>
                    </div>
                    <span className="text-sm text-gray-600">Register for tournaments near you</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="w-5 h-5 rounded-full bg-primary-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                      <svg className="w-3 h-3 text-primary-600" fill="currentColor" viewBox="0 0 12 12">
                        <path d="M10 3L4.5 8.5L2 6" stroke="currentColor" strokeWidth="2" fill="none"/>
                      </svg>
                    </div>
                    <span className="text-sm text-gray-600">Track your match schedule and results</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="w-5 h-5 rounded-full bg-primary-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                      <svg className="w-3 h-3 text-primary-600" fill="currentColor" viewBox="0 0 12 12">
                        <path d="M10 3L4.5 8.5L2 6" stroke="currentColor" strokeWidth="2" fill="none"/>
                      </svg>
                    </div>
                    <span className="text-sm text-gray-600">Build your competitive profile</span>
                  </li>
                </ul>
              </div>

              {/* Organizer Features */}
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-4">As an Organizer</h3>
                <ul className="space-y-3">
                  <li className="flex items-start gap-3">
                    <div className="w-5 h-5 rounded-full bg-primary-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                      <svg className="w-3 h-3 text-primary-600" fill="currentColor" viewBox="0 0 12 12">
                        <path d="M10 3L4.5 8.5L2 6" stroke="currentColor" strokeWidth="2" fill="none"/>
                      </svg>
                    </div>
                    <span className="text-sm text-gray-600">Set up tournaments in minutes</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="w-5 h-5 rounded-full bg-primary-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                      <svg className="w-3 h-3 text-primary-600" fill="currentColor" viewBox="0 0 12 12">
                        <path d="M10 3L4.5 8.5L2 6" stroke="currentColor" strokeWidth="2" fill="none"/>
                      </svg>
                    </div>
                    <span className="text-sm text-gray-600">Manage registrations and brackets</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="w-5 h-5 rounded-full bg-primary-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                      <svg className="w-3 h-3 text-primary-600" fill="currentColor" viewBox="0 0 12 12">
                        <path d="M10 3L4.5 8.5L2 6" stroke="currentColor" strokeWidth="2" fill="none"/>
                      </svg>
                    </div>
                    <span className="text-sm text-gray-600">Real-time scoring and updates</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </main>
      </div>
    )
  }

  // User has activity - show contextualized dashboard
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-primary-50/20">
      <Navbar />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header with Context-Aware Actions */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-8 gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-1">
              Welcome back, {user?.firstName}
            </h1>
            <p className="text-gray-600">
              Your tournaments and matches
            </p>
          </div>
          <div className="flex items-center gap-3">
            {hasOrganizations && (
              <button
                onClick={handleCreateTournament}
                className="inline-flex items-center gap-2 px-5 py-3 bg-primary-600 hover:bg-primary-700 text-white font-medium rounded-lg transition-all shadow-sm hover:shadow-md"
              >
                <PlusIcon className="w-5 h-5" />
                <span>New Tournament</span>
              </button>
            )}
            <button
              onClick={handleBrowseTournaments}
              className="inline-flex items-center gap-2 px-5 py-3 bg-white hover:bg-gray-50 text-gray-700 font-medium rounded-lg border border-gray-300 transition-all shadow-sm hover:shadow"
            >
              <SearchIcon className="w-5 h-5" />
              <span>Browse</span>
            </button>
          </div>
        </div>

        {/* PLAYER SECTION - Always Visible */}
        <div className="mb-10">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-gray-900">My Matches</h2>
            <button
              onClick={handleBrowseTournaments}
              className="text-primary-600 hover:text-primary-700 font-medium text-sm flex items-center gap-1"
            >
              <SearchIcon className="w-4 h-4" />
              Browse Tournaments
            </button>
          </div>

          {registrations.length === 0 ? (
            <div className="glass-card rounded-2xl p-12">
              <EmptyState
                icon={PlayIcon}
                title="No matches yet"
                description="Register for tournaments to see your upcoming matches and track your progress."
                action={handleBrowseTournaments}
                actionText="Browse Tournaments"
              />
            </div>
          ) : (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {registrations.map((registration) => (
                <div
                  key={registration.id}
                  className="glass-card rounded-xl p-6 hover:shadow-lg transition-all cursor-pointer border border-transparent hover:border-primary-200"
                  onClick={() => navigate(`/tournaments/${registration.event.tournament.id}`)}
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <h3 className="font-semibold text-gray-900 mb-1">{registration.event.tournament.name}</h3>
                      <p className="text-sm text-gray-600 capitalize">{registration.event.tournament.sport}</p>
                    </div>
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                      registration.event.tournament.status === 'OPEN' ? 'bg-success-100 text-success-700' :
                      registration.event.tournament.status === 'ONGOING' ? 'bg-warning-100 text-warning-700' :
                      registration.event.tournament.status === 'COMPLETED' ? 'bg-gray-100 text-gray-700' :
                      'bg-primary-100 text-primary-700'
                    }`}>
                      {registration.event.tournament.status}
                    </span>
                  </div>

                  <div className="space-y-2 mb-4">
                    <div className="flex items-center gap-2 text-sm">
                      <TrophyIcon className="w-4 h-4 text-gray-400" />
                      <span className="text-gray-700">{registration.event.name}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <CalendarIcon className="w-4 h-4 text-gray-400" />
                      <span className="text-gray-600">
                        {new Date(registration.event.tournament.startDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <svg className="w-4 h-4 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                      </svg>
                      <span className="text-gray-600">{registration.event.tournament.venueName}, {registration.event.tournament.city}</span>
                    </div>
                  </div>

                  {registration.partner && (
                    <div className="flex items-center gap-2 pt-3 border-t border-gray-100">
                      <UsersIcon className="w-4 h-4 text-primary-600" />
                      <span className="text-sm text-gray-700">
                        Partner: {registration.partner.firstName} {registration.partner.lastName}
                      </span>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* ORGANIZER SECTION - Always Visible */}
        <div className="mb-10">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-gray-900">My Organizations</h2>
            <button
              onClick={handleCreateOrganization}
              className="text-primary-600 hover:text-primary-700 font-medium text-sm flex items-center gap-1"
            >
              <PlusIcon className="w-4 h-4" />
              New Organization
            </button>
          </div>

          {organizations.length === 0 ? (
            <div className="glass-card rounded-2xl p-12">
              <EmptyState
                icon={BuildingIcon}
                title="No organizations yet"
                description="Create an organization to start managing tournaments and events for your community."
                action={handleCreateOrganization}
                actionText="Create Organization"
              />
            </div>
          ) : (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {organizations.map((org) => (
                <OrganizationCard
                  key={org.id}
                  organization={org}
                  onClick={() => handleViewOrg(org)}
                />
              ))}
            </div>
          )}
        </div>

        {/* Quick Actions - Context Aware */}
        <div className="glass-card rounded-2xl p-8">
          <h2 className="text-xl font-bold text-gray-900 mb-6">Quick Actions</h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <button
              onClick={handleBrowseTournaments}
              className="flex items-start gap-4 p-5 rounded-xl hover:bg-gray-50 transition-all text-left group border border-transparent hover:border-gray-200"
            >
              <div className="w-11 h-11 rounded-xl bg-primary-50 flex items-center justify-center text-primary-600 group-hover:scale-110 transition-transform">
                <SearchIcon className="w-5 h-5" />
              </div>
              <div className="flex-1">
                <p className="font-semibold text-gray-900 mb-0.5">Browse Tournaments</p>
                <p className="text-sm text-gray-600">Find and register for events</p>
              </div>
            </button>

            {hasOrganizations && (
              <button
                onClick={handleCreateTournament}
                className="flex items-start gap-4 p-5 rounded-xl hover:bg-gray-50 transition-all text-left group border border-transparent hover:border-gray-200"
              >
                <div className="w-11 h-11 rounded-xl bg-success-50 flex items-center justify-center text-success-600 group-hover:scale-110 transition-transform">
                  <TrophyIcon className="w-5 h-5" />
                </div>
                <div className="flex-1">
                  <p className="font-semibold text-gray-900 mb-0.5">Create Tournament</p>
                  <p className="text-sm text-gray-600">Set up a new event</p>
                </div>
              </button>
            )}

            {!hasOrganizations && (
              <button
                onClick={handleCreateOrganization}
                className="flex items-start gap-4 p-5 rounded-xl hover:bg-gray-50 transition-all text-left group border border-transparent hover:border-gray-200"
              >
                <div className="w-11 h-11 rounded-xl bg-warning-50 flex items-center justify-center text-warning-600 group-hover:scale-110 transition-transform">
                  <BuildingIcon className="w-5 h-5" />
                </div>
                <div className="flex-1">
                  <p className="font-semibold text-gray-900 mb-0.5">Create Organization</p>
                  <p className="text-sm text-gray-600">Start organizing tournaments</p>
                </div>
              </button>
            )}

            <button className="flex items-start gap-4 p-5 rounded-xl hover:bg-gray-50 transition-all text-left group border border-transparent hover:border-gray-200">
              <div className="w-11 h-11 rounded-xl bg-gray-100 flex items-center justify-center text-gray-600 group-hover:scale-110 transition-transform">
                <CalendarIcon className="w-5 h-5" />
              </div>
              <div className="flex-1">
                <p className="font-semibold text-gray-900 mb-0.5">View Schedule</p>
                <p className="text-sm text-gray-600">See all upcoming matches</p>
              </div>
            </button>
          </div>
        </div>
      </main>

      {/* Create Organization Modal */}
      <CreateOrganizationModal
        isOpen={isCreateOrgModalOpen}
        onClose={() => setIsCreateOrgModalOpen(false)}
        onSuccess={handleOrgCreated}
      />
    </div>
  )
}

export default DashboardPage
