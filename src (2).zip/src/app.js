const express = require('express');
const cors = require('cors');
const authRoutes = require('./routes/auth.routes');
const orgRoutes = require('./routes/org.routes');
const tournamentRoutes = require('./routes/tournament.routes');
const registrationRoutes = require('./routes/registration.routes');

const app = express();

// Middleware
app.use((req, res, next) => {
  console.log(`${new Date().toISOString()} ${req.method} ${req.url}`);
  next();
});

app.use(cors({
  origin: process.env.CLIENT_URL || 'http://localhost:5173',
  credentials: true,
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Routes
app.use('/auth', authRoutes);
app.use('/orgs', orgRoutes);
app.use('/tournaments', tournamentRoutes);
app.use('/', registrationRoutes); // Registration routes use /events and /users paths

// Health check
app.get('/health', (req, res) => {
  res.status(200).json({ success: true, message: 'StepOut2Play API is running' });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({
    success: false,
    error: 'Route not found',
  });
});

// Global error handler
app.use((err, req, res, next) => {
  console.error('Error:', err);

  const statusCode = err.statusCode || 500;
  const message = err.message || 'Internal server error';

  res.status(statusCode).json({
    success: false,
    error: message,
  });
});

module.exports = app;
